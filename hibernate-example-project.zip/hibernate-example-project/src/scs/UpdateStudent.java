package scs;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		System.out.println("Enter rno to update record");
		int rno = sc.nextInt();
		Student st = (Student)s.load(Student.class,rno);
		st.setRno(rno);
		st.setSname("rrrrrrrr");
		st.setBranch("EX");
		st.setFees(555555);
		s.save(st);
		tx.commit();
		sf.close();
		
		
		
		
		

	}

}
