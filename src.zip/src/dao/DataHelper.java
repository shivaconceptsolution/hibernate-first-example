package dao;
import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.*;
public class DataHelper {
	static SessionFactory sf ;
	static Session s ;
	public static void connection()
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		sf= cfg.buildSessionFactory();
		s = sf.openSession();
		
	}
	
	public static List dqlOperation(String query)
	{
		Query q = s.createQuery(query);
		return q.list();
	}
	public static void dmlOperation(Object c)
	{
		Transaction tx = s.beginTransaction();
		s.save(c);
	    tx.commit();
	   
	}
	public static void deleteOperation(Object c)
	{
		Transaction tx = s.beginTransaction();
		s.delete(c);
	    tx.commit();
	   
	}
	
	public static Object findOperation(Class c,int id)
	{
		return s.load(c,id);
	}
	
	public static void closeConn()
	{
		s.close();
		sf.close();
	
	}
	
	
   
	
}
