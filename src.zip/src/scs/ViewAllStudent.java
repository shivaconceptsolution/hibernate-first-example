package scs;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import dao.DataHelper;

public class ViewAllStudent {
public static void main(String args[])
{
	DataHelper.connection();
	
	List lst = DataHelper.dqlOperation("from Student s");
	
	Iterator it = lst.iterator();
	while(it.hasNext())
	{
		Object o = it.next();
		Student stu = (Student)o;
		System.out.println(stu.getRno() + " "+stu.getSname() + " "+stu.getBranch() + " "+stu.getFees());
		
	}
	
	DataHelper.closeConn();
	
	
	
}
}
