package scs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.*;

import dao.DataHelper;

public class InsertRecord {

	public static void main(String[] args) {
		DataHelper.connection();
		Student stu = new Student();
		stu.setRno(1005);
		stu.setSname("ABC");
		stu.setBranch("IT");
		stu.setFees(450000);
		DataHelper.dmlOperation(stu);
		DataHelper.closeConn();
	

	}

}
