package scs;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import dao.DataHelper;

public class UpdateStudent {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		DataHelper.connection();
		System.out.println("Enter rno to update record");
		int rno = sc.nextInt();
		Student st =(Student)DataHelper.findOperation(Student.class,rno);
		System.out.println(st.getRno()+" "+st.getSname());
		st.setRno(rno);
		st.setSname("rrrrrrrr");
		st.setBranch("EX");
		st.setFees(555555);
		DataHelper.dmlOperation(st);
		DataHelper.closeConn();
		
		
		
		
		

	}

}
